# 讯飞星火API密钥
APP_ID = "345ffeed"
API_KEY = "6102b1a3704f67a20d5b6e75331ed7a5"
API_SECRET = "NDhjYTgxODExY2NhZDBhYzdiOTdlZGRi"  # 请替换为您的实际密钥

# 百度千帆API配置
QIANFAN_API_KEY = "bce-v3/ALTAK-0mcbYG9MkEq3s5UWFUmo7/eff67da814e1457d00bb6135787e5df79c77aeb2"
QIANFAN_API_URL = "https://qianfan.baidubce.com/v2/chat/completions"
QIANFAN_MODEL = "ernie-3.5-8k"

# FREE-QWQ API配置
FREE_QWQ_API_KEY = "sk-W0rpStc95T7JVYVwDYc29IyirjtpPPby6SozFMQr17m8KWeo"
FREE_QWQ_API_URL = "https://api.suanli.cn/v1/chat/completions"
FREE_QWQ_MODEL = "free:QwQ-32B"